document.getElementById('spin').addEventListener('click', function() {
    const spinButton = document.getElementById('spin');
    const wheel = document.querySelector('.wheel');
    const prizeDisplay = document.getElementById('prize-display');
    const prizeText = document.getElementById('prize');
    const redeemButton = document.getElementById('redeemBtn');
    const totalRotation = Math.floor(Math.random() * 360) + 360 * 5; // זווית רנדומלית עם 5 סיבובים

    // מנטרל את כפתור ה-"Spin" לאחר לחיצה אחת
    spinButton.disabled = true;

    prizeDisplay.style.display = 'none'; // מסתיר את התצוגה הקודמת

    wheel.style.transition = 'transform 4s ease-out';
    wheel.style.transform = `rotate(${totalRotation}deg)`;

    setTimeout(function() {
        const finalRotation = totalRotation % 360; // הזווית הסופית שבה הגלגל נעצר

        // חישוב מחדש של הזווית עם פיצוי על הסגמנטים
        const correctedRotation = (360 - finalRotation) % 360; // התחשבות בכיוון הסיבוב והזווית הנוכחית

        // טווחי הזוויות לכל פרס
        const prizeRanges = [
            { min: 0, max: 29.99, text: '30% OFF' },
            { min: 30, max: 59.99, text: 'Free Return' },
            { min: 60, max: 89.99, text: 'Special Discount' },
            { min: 90, max: 119.99, text: '10% OFF Next Purchase' },
            { min: 120, max: 149.99, text: '10% OFF' },
            { min: 150, max: 179.99, text: 'Free Shipping' },
            { min: 180, max: 209.99, text: '20% OFF' },
            { min: 210, max: 239.99, text: 'Gift Voucher' },
            { min: 240, max: 269.99, text: '50% OFF' },
            { min: 270, max: 299.99, text: 'Buy 1 Get 1 Free' },
            { min: 300, max: 329.99, text: '5% OFF' },
            { min: 330, max: 359.99, text: 'Extra Gift' }
        ];

        // חיפוש הפרס המתאים על פי הזווית המחושבת מחדש
        const selectedPrize = prizeRanges.find(prize => correctedRotation >= prize.min && correctedRotation <= prize.max);

        // הצגת הפרס שנבחר
        prizeText.textContent = selectedPrize.text;
        prizeDisplay.classList.add('flash'); // הוספת אנימציית ההבהוב
        prizeDisplay.style.display = 'block'; // מציג את התצוגה

        // הצגת כפתור המימוש
        redeemButton.style.display = 'inline-block';
    }, 4000); // זמן המתנה עד שהגלגל מסיים להסתובב
});
